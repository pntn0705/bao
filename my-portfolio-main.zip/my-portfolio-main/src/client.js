import sanityClient from '@sanity/client'

export default sanityClient({
    projectId: "r99w5jgb",
    dataset: "production"
})